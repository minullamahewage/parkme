<html>
<head>
<script type="text/javascript"> 
function ThisFunc(){
	var park = new CarPark(5,7,9);
	console.log(park.getLocation());
	park.setAvailableSlots(8);
	console.log(park.getAvailableSlots());
}
</script>
<script type="text/javascript" src="classes.js"></script>
</head>
<body>
<h1>Hello World ++ Hello World</h1>
<button type="button" onclick="ThisFunc()">Click Me!</button>
<noscript>JS not Supported</noscript>
</body>
</html>